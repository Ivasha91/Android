package com.IVAN.myfirstapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView

private const val TAG = "MainActivity"
private const val MY_LOG_TAG = "MyLog"


class MainActivity : AppCompatActivity() {

    var poemStrLink = getString(R.string.poem_str_1)
    val helloTextView: TextView = findViewById(R.id.hello_text_view)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val helloTextView: TextView = findViewById(R.id.hello_text_view)
        helloTextView.text = poemStrLink
        helloTextView.textSize = 10f

        Log.d(MY_LOG_TAG, "onCreate()")
        Log.d(MY_LOG_TAG, helloTextView.text as String)
    }

    override fun onStart() {
        super.onStart()
        Log.d(MY_LOG_TAG, "onStart()")
        Log.d(MY_LOG_TAG, helloTextView.text as String)
    }

    override fun onResume() {
        super.onResume()
        Log.d(MY_LOG_TAG, "onResume()")


//        Log.d(MY_LOG_TAG, str)

    }

    fun poemToDebug(){
        var strNum = 1
        if (strNum == 1){
            poemStrLink = getString(R.string.poem_str_1)
        } else if (strNum == 2) {
            poemStrLink = getString(R.string.poem_str_2)
        } else if (strNum == 3) {
            poemStrLink = getString(R.string.poem_str_3)
        } else if (strNum == 4) {
            poemStrLink = getString(R.string.poem_str_4)
        } else if (strNum == 5) {
            poemStrLink = getString(R.string.poem_str_5)
        } else if (strNum == 6) {
            poemStrLink = getString(R.string.poem_str_6)
        } else if (strNum == 7) {
            poemStrLink = getString(R.string.poem_str_7)
        } else if (strNum == 8) {
            poemStrLink = getString(R.string.poem_str_8)
        } else if (strNum == 9) {
            poemStrLink = getString(R.string.poem_str_9)
        } else if (strNum == 10) {
            poemStrLink = getString(R.string.poem_str_10)
        } else if (strNum == 11) {
            poemStrLink = getString(R.string.poem_str_11)
        } else if (strNum == 12) {
            poemStrLink = getString(R.string.poem_str_12)
        } else {
            strNum = 1
        }
    }


    override fun onPause() {
        super.onPause()
        Log.d(MY_LOG_TAG, "onPause()")
    }

    override fun onStop() {
        super.onStop()
        Log.d(MY_LOG_TAG, "onStop()")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(MY_LOG_TAG, "onRestart()")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(MY_LOG_TAG, "onDestroy()")
    }

}